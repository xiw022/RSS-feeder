=========
 History
=========

1.3.1

  - Updated build to work with hg and migrated code to bitbucket
    hosting. No source changes.

1.3

  - Supports purging cache contents, based on a suggestion by Thomas Perl.

1.2

  - Add a bit of documentation.

1.1

  - New features based on a patch from Thomas Perl:

   * Unicode handling for URLs.
   * force_update flag
   * offline mode flag

1.0

  - Lock down the API from the last alpha version, and move to beta
    status.

0.5

  - Add tests that illustrate using ``feedcache`` with shove.

0.4

  - API changes and additional tests.

0.3

  - Eliminates a race condition in the backend storage API.

0.2

  - Improve the ShelveStorage backend and add an example script to
    illustrate how to use the cache.

0.1

  - Early alpha version with in-memory and shelve storage options for
    the backend.
